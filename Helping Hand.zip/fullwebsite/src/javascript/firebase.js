
  var firebaseConfig = {
    apiKey: "AIzaSyATl63Yxp9wYammrpshOKNJs3sWmmsBn3k",
    authDomain: "first-login-289c3.firebaseapp.com",
    projectId: "first-login-289c3",
    storageBucket: "first-login-289c3.appspot.com",
    messagingSenderId: "125736266797",
    appId: "1:125736266797:web:84d1c5038796ac70325ca4"
  };

firebase.initializeApp(firebaseConfig);
